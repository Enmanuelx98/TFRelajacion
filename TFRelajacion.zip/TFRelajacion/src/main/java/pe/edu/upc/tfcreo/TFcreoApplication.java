package pe.edu.upc.tfcreo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TFcreoApplication {

    public static void main(String[] args) {
        SpringApplication.run(TFcreoApplication.class, args);
    }

}
