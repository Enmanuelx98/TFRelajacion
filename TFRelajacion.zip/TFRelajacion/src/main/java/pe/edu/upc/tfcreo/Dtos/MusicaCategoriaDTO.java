package pe.edu.upc.tfcreo.Dtos;


public class MusicaCategoriaDTO {
    private int idMusicaCategoria;
    private String nombreCategoria;

    public int getIdMusicaCategoria() {
        return idMusicaCategoria;
    }

    public void setIdMusicaCategoria(int idMusicaCategoria) {
        this.idMusicaCategoria = idMusicaCategoria;
    }

    public String getNombreCategoria() {
        return nombreCategoria;
    }

    public void setNombreCategoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }
}
